package com.example.portal.exception;

import lombok.Getter;

@Getter
public class ResourceNotFoundException extends BusinessException {
    private final String resourceName;
    private final Object resourceId;

    public ResourceNotFoundException(String resourceName, Object resourceId) {
        super(String.format("%s with id %s not found", resourceName, resourceId), "RESOURCE_NOT_FOUND");
        this.resourceName = resourceName;
        this.resourceId = resourceId;
    }

    public ResourceNotFoundException(String message) {
        super(message, "RESOURCE_NOT_FOUND");
        this.resourceName = null;
        this.resourceId = null;
    }
}