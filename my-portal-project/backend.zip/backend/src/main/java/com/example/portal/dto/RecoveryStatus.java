package com.example.portal.dto;

public enum RecoveryStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    FAILED
}