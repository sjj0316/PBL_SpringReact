package com.example.portal.service;

import com.example.portal.dto.UserProfileResponse;
import com.example.portal.dto.UserProfileUpdateRequest;
import com.example.portal.dto.user.UserResponse;
import com.example.portal.dto.UserUpdateRequest;
import com.example.portal.entity.User;
import com.example.portal.exception.UserException;
import com.example.portal.repository.UserRepository;
import com.example.portal.security.UserPrincipal;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import jakarta.persistence.EntityNotFoundException;

/**
 * 사용자 관련 비즈니스 로직을 처리하는 서비스
 * 사용자 프로필 조회, 수정 등의 기능을 제공합니다.
 */
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class UserService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    // 사용자명으로 사용자 조회
    public User getUserByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new EntityNotFoundException("사용자가 존재하지 않습니다."));
    }

    // 이메일로 사용자 조회
    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new EntityNotFoundException("사용자가 존재하지 않습니다."));
    }

    // 사용자 존재 여부 확인
    public boolean existsByUsername(String username) {
        return userRepository.existsByUsername(username);
    }

    // 이메일 존재 여부 확인
    public boolean existsByEmail(String email) {
        return userRepository.existsByEmail(email);
    }

    // 사용자 생성
    @Transactional
    public User createUser(User user) {
        if (existsByUsername(user.getUsername())) {
            throw new IllegalStateException("이미 존재하는 사용자명입니다.");
        }
        if (existsByEmail(user.getEmail())) {
            throw new IllegalStateException("이미 존재하는 이메일입니다.");
        }
        return userRepository.save(user);
    }

    // 사용자 정보 수정
    @Transactional
    public User updateUser(Long id, User user) {
        User existingUser = userRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("사용자가 존재하지 않습니다."));

        // 이메일 변경 시 중복 체크
        if (!existingUser.getEmail().equals(user.getEmail()) && existsByEmail(user.getEmail())) {
            throw new IllegalStateException("이미 존재하는 이메일입니다.");
        }

        existingUser.setEmail(user.getEmail());
        existingUser.setName(user.getName());
        existingUser.setPicture(user.getPicture());

        return existingUser;
    }

    // 사용자 삭제
    @Transactional
    public void deleteUser(Long id) {
        if (!userRepository.existsById(id)) {
            throw new EntityNotFoundException("사용자가 존재하지 않습니다.");
        }
        userRepository.deleteById(id);
    }

    /**
     * 사용자 프로필 정보를 조회합니다.
     * 
     * @param email 사용자 이메일
     * @return 사용자 프로필 정보
     * @throws UsernameNotFoundException 사용자를 찾을 수 없는 경우
     */
    public UserProfileResponse getUserProfile(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("사용자를 찾을 수 없습니다: " + email));

        return new UserProfileResponse(user.getEmail(), user.getName(), user.getRole());
    }

    /**
     * 사용자 프로필 정보를 수정합니다.
     * 이름 변경 및 비밀번호 변경을 지원합니다.
     * 
     * @param email   사용자 이메일
     * @param request 수정할 프로필 정보
     * @return 수정된 사용자 프로필 정보
     * @throws UsernameNotFoundException 사용자를 찾을 수 없는 경우
     * @throws IllegalArgumentException  유효하지 않은 요청 데이터인 경우
     */
    @Transactional
    public UserProfileResponse updateUserProfile(String email, UserProfileUpdateRequest request) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("사용자를 찾을 수 없습니다: " + email));

        // 이름 수정
        if (request.getName() != null && !request.getName().trim().isEmpty()) {
            user.setName(request.getName().trim());
        }

        // 비밀번호 수정
        if (request.getNewPassword() != null && !request.getNewPassword().trim().isEmpty()) {
            validatePasswordChange(request);
            user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        }

        userRepository.save(user);
        return getUserProfile(email);
    }

    /**
     * 비밀번호 변경 요청의 유효성을 검사합니다.
     * 
     * @param request 비밀번호 변경 요청
     * @throws IllegalArgumentException 유효하지 않은 비밀번호 변경 요청인 경우
     */
    private void validatePasswordChange(UserProfileUpdateRequest request) {
        if (request.getCurrentPassword() == null || request.getCurrentPassword().trim().isEmpty()) {
            throw new IllegalArgumentException("현재 비밀번호를 입력해주세요.");
        }

        if (request.getNewPassword().length() < 8) {
            throw new IllegalArgumentException("새 비밀번호는 8자 이상이어야 합니다.");
        }
    }

    @Transactional(readOnly = true)
    public UserResponse getCurrentUser(UserPrincipal userPrincipal) {
        User user = userRepository.findById(userPrincipal.getId())
                .orElseThrow(() -> new UserException("사용자를 찾을 수 없습니다."));
        return UserResponse.from(user);
    }

    @Transactional
    public UserResponse updateCurrentUser(UserPrincipal userPrincipal, UserUpdateRequest request) {
        User user = userRepository.findById(userPrincipal.getId())
                .orElseThrow(() -> new UserException("사용자를 찾을 수 없습니다."));

        // 현재 비밀번호 확인
        if (!passwordEncoder.matches(request.getCurrentPassword(), user.getPassword())) {
            throw new UserException("현재 비밀번호가 일치하지 않습니다.");
        }

        // 이메일 중복 확인
        if (!user.getEmail().equals(request.getEmail()) &&
                userRepository.existsByEmail(request.getEmail())) {
            throw new UserException("이미 사용 중인 이메일입니다.");
        }

        // 사용자 정보 업데이트
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setProfileImageUrl(request.getProfileImageUrl());

        if (request.getNewPassword() != null && !request.getNewPassword().isEmpty()) {
            user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        }

        return UserResponse.from(userRepository.save(user));
    }

    @Transactional
    public UserResponse updateProfileImage(UserPrincipal userPrincipal, String profileImageUrl) {
        User user = userRepository.findById(userPrincipal.getId())
                .orElseThrow(() -> new UserException("사용자를 찾을 수 없습니다."));

        user.setProfileImageUrl(profileImageUrl);
        return UserResponse.from(userRepository.save(user));
    }

    public UserResponse getUserProfile(Long userId) {
        // Implementation needed
        throw new UnsupportedOperationException("Method not implemented");
    }

    public UserResponse updateUserProfile(Long userId, String name, MultipartFile profileImage) {
        // Implementation needed
        throw new UnsupportedOperationException("Method not implemented");
    }

    public void deleteUser(Long userId) {
        // Implementation needed
        throw new UnsupportedOperationException("Method not implemented");
    }

    public void changePassword(Long userId, String currentPassword, String newPassword) {
        // Implementation needed
        throw new UnsupportedOperationException("Method not implemented");
    }
}