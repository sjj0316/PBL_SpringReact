package com.example.portal.service.impl;

import com.example.portal.dto.user.UserResponse;
import com.example.portal.entity.User;
import com.example.portal.exception.ResourceNotFoundException;
import com.example.portal.exception.UnauthorizedException;
import com.example.portal.repository.UserRepository;
import com.example.portal.security.SecurityUtil;
import com.example.portal.service.FileStorageService;
import com.example.portal.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final FileStorageService fileStorageService;

    @Override
    public UserResponse getUserProfile(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("사용자를 찾을 수 없습니다."));
        return UserResponse.from(user);
    }

    @Override
    @Transactional
    public UserResponse updateUserProfile(Long userId, String name, MultipartFile profileImage) {
        User currentUser = SecurityUtil.getCurrentUser();
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("사용자를 찾을 수 없습니다."));

        if (!user.getId().equals(currentUser.getId())) {
            throw new UnauthorizedException("프로필을 수정할 권한이 없습니다.");
        }

        if (name != null && !name.isBlank()) {
            user.updateName(name);
        }

        if (profileImage != null && !profileImage.isEmpty()) {
            String profileImageUrl = fileStorageService.storeFile(profileImage);
            user.updateProfileImage(profileImageUrl);
        }

        return UserResponse.from(user);
    }

    @Override
    @Transactional
    public void deleteUser(Long userId) {
        User currentUser = SecurityUtil.getCurrentUser();
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("사용자를 찾을 수 없습니다."));

        if (!user.getId().equals(currentUser.getId())) {
            throw new UnauthorizedException("계정을 삭제할 권한이 없습니다.");
        }

        userRepository.delete(user);
    }

    @Override
    @Transactional
    public void changePassword(Long userId, String currentPassword, String newPassword) {
        User currentUser = SecurityUtil.getCurrentUser();
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("사용자를 찾을 수 없습니다."));

        if (!user.getId().equals(currentUser.getId())) {
            throw new UnauthorizedException("비밀번호를 변경할 권한이 없습니다.");
        }

        if (!passwordEncoder.matches(currentPassword, user.getPassword())) {
            throw new UnauthorizedException("현재 비밀번호가 일치하지 않습니다.");
        }

        user.updatePassword(passwordEncoder.encode(newPassword));
    }
}